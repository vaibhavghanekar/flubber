package com.appolica.sample.ui.editor.pager.settings;

public interface OnFieldChangedListener {
    void onPropertyChanged(SeekBarModel model);
}
