package com.appolica.sample.ui.main;

import android.view.View;

public interface FlubberClickListener {
    void onFlubberClick(View view);
}
