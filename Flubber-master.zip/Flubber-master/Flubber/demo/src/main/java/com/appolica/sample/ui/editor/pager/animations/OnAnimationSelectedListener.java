package com.appolica.sample.ui.editor.pager.animations;

import com.appolica.flubber.Flubber;

public interface OnAnimationSelectedListener {
    void onAnimationSelected(Flubber.AnimationProvider animationProvider);
}
