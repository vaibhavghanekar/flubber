package com.appolica.sample.ui.editor.pager.interpolators;

import com.appolica.flubber.Flubber;

public interface OnInterpolatorSelectedListener {
    void onInterpolatorSelected(Flubber.Curve interpolator);
}
