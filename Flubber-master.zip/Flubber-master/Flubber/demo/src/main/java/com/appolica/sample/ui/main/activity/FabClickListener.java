package com.appolica.sample.ui.main.activity;

public interface FabClickListener {
    void onAddClick();
    void onDoneClick();
}
