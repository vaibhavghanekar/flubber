package com.appolica.sample.ui.editor.pager;

import com.appolica.sample.ui.animation.CustomAnimationBody;

public interface AnimationBodyProvider {
    CustomAnimationBody getAnimationBody();
}
