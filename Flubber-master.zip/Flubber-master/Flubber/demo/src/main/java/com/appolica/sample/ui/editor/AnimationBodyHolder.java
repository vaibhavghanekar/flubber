package com.appolica.sample.ui.editor;

import com.appolica.sample.ui.animation.CustomAnimationBody;

public interface AnimationBodyHolder {
    void setAnimationBody(CustomAnimationBody animationBody);
}
